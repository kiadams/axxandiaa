import argparse
import datetime

def append_to_file(filename, text):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(filename, "a") as file:
        file.write(f"[{timestamp}] {text}\n")
    print(f"Text appended to {filename}")

if __name__ == "__main__":
    OUTPUT_FILE = "C:\\Users\\User\\Downloads\\Obsoutput.txt"  # Specify the output file here
    TEXT_TO_APPEND = "Obfuscated and Encrypted XWorm"  # Specify the text here
    
    append_to_file(OUTPUT_FILE, TEXT_TO_APPEND)
