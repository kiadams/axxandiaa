import os
import sys
from datetime import datetime

def bin_to_text(input_bin_file):
    # Define the output file path on the desktop
    desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
    output_txt_file = os.path.join(desktop_path, "output.txt")
    
    try:
        # Open the .bin file in read-binary mode
        with open(input_bin_file, 'rb') as bin_file:
            # Read the binary content
            binary_data = bin_file.read()

            # Convert the binary data to a readable text (assuming UTF-8 encoding or printable chars)
            try:
                text_data = binary_data.decode('utf-8')
            except UnicodeDecodeError:
                text_data = str(binary_data)  # Fallback to raw byte string if decoding fails

            # Get the current timestamp
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            # Prepare the content with timestamp
            content_with_timestamp = f"Timestamp: {timestamp}\n"
            content_with_timestamp += text_data + "\n\n"  # Add the binary data with a newline for separation

            # Append the output to the text file on the desktop (if it exists)
            with open(output_txt_file, 'a', encoding='utf-8') as text_file:  # 'a' mode for append
                text_file.write(content_with_timestamp)

            print(f"Output appended to: {output_txt_file}")
    except FileNotFoundError:
        print(f"The file {input_bin_file} does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    # Check if the user provided a filename as an argument
    if len(sys.argv) != 2:
        print("Usage: python load.py <path_to_bin_file>")
        sys.exit(1)
    
    # Get the .bin file from the command-line argument
    input_bin_file = sys.argv[1]

    # Run the function to process the .bin file
    bin_to_text(input_bin_file)
